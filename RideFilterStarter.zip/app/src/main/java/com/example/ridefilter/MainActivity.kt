package com.example.ridefilter

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
        }

        fun addText(text: String, size: Float, bold: Boolean = false) {
            page.addView(TextView(this).apply {
                this.text = text
                textSize = size
                if (bold) setTypeface(null, Typeface.BOLD)
                setPadding(0, dp(6), 0, dp(8))
            })
        }

        fun field(hint: String, initial: String): EditText {
            return EditText(this).apply {
                this.hint = hint
                setText(initial)
                inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                    android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
                page.addView(this, ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ))
            }
        }

        addText("Ride Fare Filter", 26f, true)
        addText("Rapido • Ola • Uber — starter demo", 15f)
        addText("यह शुरुआती डेमो है। यह दूसरी ऐप की राइड नहीं पढ़ता और Accept नहीं करता।", 14f)

        addText("न्यूनतम किराया (₹)", 16f, true)
        val minFare = field("जैसे 100", "100")
        addText("अधिकतम किराया (₹)", 16f, true)
        val maxFare = field("जैसे 500", "500")
        addText("टेस्ट राइड का किराया (₹)", 16f, true)
        val testFare = field("जैसे 180", "180")

        val result = TextView(this).apply {
            text = "टेस्ट चलाएँ दबाकर फ़िल्टर जाँचें।"
            textSize = 17f
            setPadding(0, dp(16), 0, dp(16))
        }
        page.addView(result)

        page.addView(Button(this).apply {
            text = "टेस्ट राइड जाँचें"
            setOnClickListener {
                val min = minFare.text.toString().toDoubleOrNull()
                val max = maxFare.text.toString().toDoubleOrNull()
                val fare = testFare.text.toString().toDoubleOrNull()

                result.text = when {
                    min == null || max == null || fare == null ->
                        "कृपया सभी फ़ील्ड में सही नंबर डालें।"
                    min < 0 || max < min || fare < 0 ->
                        "किराये की सीमा जाँचें। अधिकतम किराया न्यूनतम से कम नहीं हो सकता।"
                    fare in min..max ->
                        "MATCH ✓  ₹$fare आपकी ₹$min–₹$max सीमा में है।\nयह केवल डेमो है; कोई राइड स्वीकार नहीं हुई।"
                    else ->
                        "SKIP ✕  ₹$fare आपकी ₹$min–₹$max सीमा से बाहर है।\nयह केवल डेमो है; कोई राइड स्वीकार नहीं हुई।"
                }
            }
        })

        addText("अगला चरण", 18f, true)
        addText("वास्तविक राइड डेटा के लिए प्लेटफ़ॉर्म की अनुमति/आधिकारिक इंटीग्रेशन चाहिए। अनजान APK या Play Protect बंद करने वाले निर्देशों से बचें।", 14f)

        setContentView(page)
    }
}
